______               _                
| ___ \             | |               
| |_/ /___  __ _  __| |_ __ ___   ___ 
|    // _ \/ _` |/ _` | '_ ` _ \ / _ \
| |\ \  __/ (_| | (_| | | | | | |  __/
\_| \_\___|\__,_|\__,_|_| |_| |_|\___|

Egg Move Editor
Version 1.33
By FinalZero
March 9th, 2010

// About
//---------------------------------------------------------------------------

This program edits the egg moves of a generation III Pok�mon game. Egg moves are the moves that a pokemon learns when it hatches from a egg if its father knew the move (excluding those of TMs).

English and French language games are supported. If you would like for support of generation III games in another language to be added, or the program's interface to be in another language, send me a PM or an email and I'll then work with you to add the language support desired.

// Operation
//---------------------------------------------------------------------------

Export List as .txt - This button saves a .txt file with a list of all the egg moves displayed currently.
Modify Entry - This button changes the entry selected to what is chosen in the drop down box.
Insert Entry - This button inserts an entry of what is selected in the drop down box. The final entry of the list will then be deleted because the length of the list must stay the same size. I'm still researching whether it's possible to repoint the list.
Delete Entry - This button deletes the entry selected. Again, since I don't know if it's possible to change the size of the list, it moves all entries below the selected one up, and then changes the last one to "????????". Such a procedure achieves the same effect.

// Errors
//---------------------------------------------------------------------------

You may get an error about .dll files missing. Four .dll files that are needed for this program to run, but they aren't included with Windows by default. These files can be downloaded from my website and then placed in the C:\WINDOWS\system32 directory. The files needed are:
1) vcl100.bpl
2) rtl100.bpl
3) borlndmm.dll
4) cc3280mt.dll

// Contact
//---------------------------------------------------------------------------

New versions of this program (and old ones too) can be found at http://jc.tech-galaxy.com/.

I may be contacted at FinalZero_17@hotmail.com with any questions and/or concerns regarding this program and/or any related material.

// Thanks
//---------------------------------------------------------------------------

Thanks to Teh Baro for providing the information on how to edit egg moves, thanks to Link_971 for providing the offsets of French language roms and translations for the French interface, and thanks to http://www.network-science.de/ascii/ for providing the ascii art used at the top of this readme.

// Version Log
//---------------------------------------------------------------------------

Version 1.33 - March 9th, 2010
-------------------------------
- Because of problems with Vista, I made it so that the .bpl and .dll files are no longer needed to run the program.

Version 1.32 - November 27th, 2009
-----------------------------------
- Fixed a flaw with the insert button.

Version 1.31 - November 20th, 2009
-----------------------------------
- Corrected an open dialog error.

Version 1.30 - November 19th, 2009
-----------------------------------
- Changed the layout of the program.
- Changed the internal structure of the program.

Version 1.22 - November 11th, 2009
-----------------------------------
- Changed the layout of the program.
- Added a close option to the menu.
- Fixed an error when using the program with desktop that spans more than one monitor.

Version 1.20 - August 10th, 2009
----------------------------------
- Fixed the resizing of the window issue.
- Fixed some French translations.
- Moved the Open and Save buttons to the Menu Bar.

Version 1.10 - May 31st, 2009
-------------------------------
- Fixed an error with the modify button and the insert button.
- Added support for all French language generation III games.
- Added a language tab under the options menu to change the language of the interface. English and French interfaces are available.
- Let roms that don't end with .gba able to be opened.
- Egg move lists that are corrupt are now uncorrupted by the program automatically.
- Fixed "Number of Pokemon" and "Number of Moves" labels.
- Added a button that checks for duplicate entries, but it doesn't work properly yet so it's disabled for now.

Version 1.00 - May 25th, 2009
-------------------------------
- Support for all English language generation III games is present.
