******************************************************
*** Advance Map Vers�o 1.80 - Portugu�s Brasileiro ***
******************************************************

Este programa � para a edi��o do mapa, das permiss�es do movimento, dos dados do bloco, 
dos eventos e de dados selvagens do pokemon. Uns dados mais atrasados da colis�o devem 
tamb�m ser edit�veis. Funciona com a Gera��o Advanced Pok�mon (R/S/E/FR/LG), 
japon�s e ingl�s.      


!!!Attention!!!
-------------
Com esta vers�o todas as mudan�as s�o conservadas diretamente na ROM!  
Atrav�s de "Salvar como" voc� pode conservar o mapa atual em uma outro arquivo.  
Carregou uma vez uma c�pia do arquivo atual � feito. Todas as mudan�as mais adicionais 
s�o armazenados no arquivo novo.



.:|IMPORTANTE|:.
-^-^-^-^-^-^-^-
Este programa foi programado por Lu-ho Pok�
e conseq�entemente seu copyright pertence a ele!  
Se voc� fez o download de um outro lugar que n�o seja 
Filb's World board [http://www.filbboard.de ]
diga-me por favor! Meu email �: lu.ho@tiscali.ch


A parte que fala dos INIs foi cortada dessa tradu��o


********************************
***      Agradecimentos      ***
********************************
Agradecimentos maiores para:
Jigglypuff pelo Source do Goldmap2 Beta
e Jay, que me entregou.

O resto dos agradecimentos:
Tauwasser e F-Zero pelos tutoriais.
Mikaron pelo seu trabalho.
Serwe por me dar id�ias.
Mulle que me fez errar.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun e outros pela tradu��o dos INIs.
And e � claro, Filb por seu f�rum.
Outro agradecimento vai para F-Zero que me ajudou me com as Sprite-Pallets.
Tamb�m dark01 recebeu um grande obrigado pela ajuda com os sprites.
Obrigado a evilboy pela ajuda com os FAQs.
Mais agradecimento para Scizz, dark01, BlueSonic and F-Zero pelos BetaTests.