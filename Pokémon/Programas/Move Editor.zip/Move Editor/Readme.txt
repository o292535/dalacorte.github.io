______               _                
| ___ \             | |               
| |_/ /___  __ _  __| |_ __ ___   ___ 
|    // _ \/ _` |/ _` | '_ ` _ \ / _ \
| |\ \  __/ (_| | (_| | | | | | |  __/
\_| \_\___|\__,_|\__,_|_| |_| |_|\___|

Move Editor
Version 1.10
By FinalZero
September 20th, 2010

// About
//---------------------------------------------------------------------------

This program edits the moves of a generation III Pok�mon game.

// Operation
//---------------------------------------------------------------------------

1) First load a rom, then click on a move in the list box and change the desired data. Then go up to the menu bar and click save. The changes for that move won't be recorded if you click on a move in the list box before clicking save.
2) When changing the name one can use multi-character symbols like [m] and [f] to stand for the male and female symbol respectively.
3) Power values can only be between 0 inclusive and 255 inclusive, so any number entered that's larger or smaller than that will be reduced to within that range by modding it by 256.
4) Accuracy values are traditionally between 0 inclusive and 100 inclusive, so don't try changing them to something beyond that range.
5) I'm unsure what will happen if the PP value is stretched to a large number like 200 and then PP Ups (or a PP Max) are applied, so avoid changing it to something absurd. (159 is the theoretical threshold for no overflow looping happening after applying PP Ups, but I haven't tested this yet.)
6) Some effect descriptions have an asterisk before them. This means that the effect doesn't actually do anything because it was never used in the game. But according to the format that the effects follow, it's what theoretically should be there. So please, someone learn how to edit move effects and make such effects actually work!
7) Many effect descriptions are just the name of a move within parentheses. This means that the move was too long to describe and/or I figure everyone already knows what the effect is, so I didn't bother including it.
8) Many effect descriptions are simply just a number. This means that the effect does nothing and is never used within the game, and has no theoretical effects that should be there.
9) Many more target combinations are actually available, but not a single move in the game uses them, so I've omitted the option of selecting them.
10) I have created a sound-based move editor as a separate program. It can be found on my website.

// Contact
//---------------------------------------------------------------------------

New versions of this program can be found at: http://jc.tech-galaxy.com/

I may be contacted at FinalZero_17@hotmail.com with any questions and/or concerns regarding this program and/or any related material.

// Thanks
//---------------------------------------------------------------------------

Thanks to Bulbapedia for providing the information on the data structure of a move.

// Version Log
//---------------------------------------------------------------------------

Version 1.10 - September 20th, 2010
------------------------------------
- Added the ability to edit descriptions and repoint their pointers.
- Added the ability to edit contest data except for descriptions.
- Reorganized the items in menu bar.
- Added macros which can quickly change the case of all move names.
- Added French language interface except for effect descriptions.
- Added French language support for roms.

Version 1.02 - March 9th, 2010
-------------------------------
- Because of problems with Vista, I made it so that the .bpl and .dll files are no longer needed to run the program.

Version 1.01 - January 4th, 2010
---------------------------------
- Fixed the tab order of the edit boxes and combo boxes.
- Added some more effect descriptions.
- Reorganized the readme.

Version 1.00 - November 22nd, 2009
-----------------------------------
- Only English games are supported.
- Only an English interface is present.
