                                             --Item Image Editor--
 
                                             � 2008 Swampert Tools

This tool requires a bit of understanding, so I thought I'd do a ReadMe!

The purpose of this program is really for adding new items over blank spaces.

First of all, you need to get your indexed item sprite and burn the image and pallete to your ROM using unLZ.GBA into
a blank space. Remember the offsets you picked, then find the item that you want to change.

Click on it and the offsets for the image and pallete will be dispayed.

The default for a blank item is:

Image = E87028
Pallete = E870A0

Then, in the relevant boxes, type your new offsets and hit File,Save.

The data will be saved and your item will have a different image!

Warning: Do not put in characters that are not valid Hex characters as this will write over the next item's offset.

--------------------------------------------------------------------------------------------------------------------------

Thanks to Darthatron for his help on offsets, HexFunctions and inspiration to become a programmer!

Check out some of my other tools like

Pok�mon Red/Blue/Yellow Mart Editor
Pok�mon Red/Blue Gym and Elite 4 Editor
Pok�mon Red/Blue Titlescreen Editor
Pok�mon Gold/Silver/Crystal TM Editor
Pok�mon Gold/Silver Mart Editor

They're all on DataCrystal:

http://www.datacrystal.org/wiki/Pokemon_Red/Blue
http://www.datacrystal.org/wiki/Pokemon_Gold/Silver

Also, visit pkmncommunity.com for a friendly forum of Pok�mon fans!

This version: 8/5/2008 - Support for Leaf Green and Emerald versions added ^_^