
			 Start Map Chooser Advance (aka SMCA) v1.2.0

		   Copyrigth � 2006-2007 Andrea Sartori aka Mew2 aka HackMew

 ===========================================================================================
					-DESCRIPTION-
 ===========================================================================================

		A program to change Start Map in Pok�mon-Advance ROMs.

 ===========================================================================================
				       -ROMs SUPPORTED-
 ===========================================================================================
		
		+ Ruby (Japanese, English, Italian, Spanish, French, German)
		+ Sapphire (Japanese, English, Italian, Spanish, French, German)
		+ Emerald (Japanese, English, Italian, Spanish, French, German)
		+ Fire Red (Japanese, English, Italian, Spanish, French, German)
		+ Leaf Green (Japanese, English, Italian, Spanish, French, German)

 ===========================================================================================
				       -INSTRUCTIONS-
 ===========================================================================================

 1) Open your favourite ROM.
 2) Now you can see in the textboxes the current Start Map.
 3) Choose what Bank/Level you want and save when you're done.
 
Enjoy ;)	
