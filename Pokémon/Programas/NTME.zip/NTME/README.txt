 _   _ _______ __  __ ______ 
| \ | |__   __|  \/  |  ____|
|  \| |  | |  | \  / | |__   
| . ` |  | |  | |\/| |  __|  
| |\  |  | |  | |  | | |____ 
|_| \_|  |_|  |_|  |_|______|

Nameless Tile Map Editor [v1.1]

	Prorgammed by D-Trogh

NOTE:	- Report any bugs/oddities to Diven_Shadow[AT]hotmail. com OR Diven-Trogh[AT]hotmail.com
	- Darthatron (darthatron@darthatron.com) programmed the base for this program.
	  He gave me the source, and I was allowed to edit it.

	- Never remove or modify this README.txt when you put it online for download!