Hehe, simple Readme...


Click Load ROM

Select a Pokemon Fire Red US [BPRE] Rom.

(It must be ENGLISH, and have the ROM header BPRE!!!!)

Change the attacks listed in the boxes to choose your attack!

Click Save, and you are done.

If you like it, give me some reputation points!  ^_^

Enjoy!