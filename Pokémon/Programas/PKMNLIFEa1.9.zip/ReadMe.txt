======PKMN LIFE VERSION======

Pok�mon: LIFE Version is a Pok�mon hack of a FireRed English Rom (BPRE).
This .zip file contains the .IPS Patch that must be applied to the .GBA file

If you do not know what an IPS Patch is or how it works, check this thread:
http://www.pokecommunity.com/showthread.php?t=73966

===========ALPHA 1===========

Bugs:	The Pok�dex (It wasn't hacked just yet, so do not use it);
	Playing with music is not recommended;
	Some Pok�mon still have only 1 frame animation;
	Solving the puzzle will result in nothing;
	Black&White Music and Clarity enhancements are not inserted yet;
	People who applied for trainers of citizens may not appear due the game's current lenght.

Stats/Abilities/Moves/Evolutions have been changed and not cataloged yet.

The Alpha ends when the Geisha tells you.
=============================
For further information, credits and bug report, check this thread: http://www.pokecommunity.com/showthread.php?t=333051
=============================